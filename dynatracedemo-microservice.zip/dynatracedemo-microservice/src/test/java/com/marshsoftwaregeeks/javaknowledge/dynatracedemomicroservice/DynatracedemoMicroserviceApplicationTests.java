package com.marshsoftwaregeeks.javaknowledge.dynatracedemomicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynatracedemoMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
