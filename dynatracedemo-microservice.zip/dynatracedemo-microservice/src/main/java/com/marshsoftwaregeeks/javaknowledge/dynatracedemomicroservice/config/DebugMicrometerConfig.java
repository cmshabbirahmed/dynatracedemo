//package com.marshsoftwaregeeks.javaknowledge.dynatracedemomicroservice.config;
//
//
//import io.micrometer.core.instrument.MeterRegistry;
//import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class DebugMicrometerConfig {
//    @Bean
//    public MeterRegistryCustomizer<MeterRegistry> logRegistryCustomizer() {
//        return registry -> System.out.println("👉 MeterRegistry class: " + registry.getClass().getName());
//    }
//}
