package com.marshsoftwaregeeks.javaknowledge.dynatracedemomicroservice.testclass;

import java.net.HttpURLConnection;
import java.net.URL;

public class DynatracePingTest {

    public static void main(String[] args) throws Exception {
        URL url = new URL("https://kbs54697.live.dynatrace.com/api/v2/metrics/ingest");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Authorization", "Api-Token dt0c01.655BJP4WTSUVRXXI6SILSTJC.OD4LVHJKE3XOBG3SZ2N7LICVHBOFN7GTEJUORI67TKFVW2PQKVKUMUIXFLHNN76M"); // Use your token here
        con.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
        con.setDoOutput(true);
        con.getOutputStream().write("custom_demo_counter count,delta=1".getBytes());
        System.out.println("Response code: " + con.getResponseCode());
    }
}
