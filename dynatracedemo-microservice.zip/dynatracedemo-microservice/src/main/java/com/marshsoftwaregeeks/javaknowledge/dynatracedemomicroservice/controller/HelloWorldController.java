package com.marshsoftwaregeeks.javaknowledge.dynatracedemomicroservice.controller;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class HelloWorldController {

    RestTemplate restTemplate = new RestTemplate();

    private static final Logger logger = LoggerFactory.getLogger(HelloWorldController.class);
    @Value("${management.metrics.export.dynatrace.api-token}")
String apiToken;

    @Value("${management.metrics.export.dynatrace.uri}")
    String dynatraceUri;

    @PostConstruct
    public void logStartup() {
        logger.info("🚀 Controller initialized and logging works");
    }


    private final Counter demoCounter;

    public HelloWorldController(MeterRegistry meterRegistry) {
        this.demoCounter = meterRegistry.counter("custom_demo_counter", "endpoint", "/hello");
    }

    @RequestMapping("/hello")
    public String index() {
        demoCounter.increment(); // ✅ Important: increments the counter
        return "Hello World!";
    }

    @PostMapping("/hello")
    public String postHello() {
        demoCounter.increment();
        logger.info("POST /hello called - counter incremented");
        return "Hello World via POST!";
    }

    @PostMapping("/send-metric")
    public ResponseEntity<String> sendMetricToDynatrace(@RequestBody(required = false) String metricPayload) {
        try {
            String payload = (metricPayload == null || metricPayload.isEmpty())
                    ? "custom_demo_counter count,delta=1"
                    : metricPayload;

            logger.info("Sending metric to Dynatrace: {}", payload);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Api-Token " + apiToken);
            headers.setContentType(MediaType.TEXT_PLAIN);

            var request = new org.springframework.http.HttpEntity<>(payload, headers);
            var response = restTemplate.postForEntity(dynatraceUri, request, String.class);

            logger.info("Dynatrace response: {}", response.getStatusCode());
            return ResponseEntity.status(response.getStatusCode()).body(response.getBody());
        } catch (Exception e) {
            logger.error("Error sending metric to Dynatrace", e);
            return ResponseEntity.status(500).body("Error sending metric: " + e.getMessage());
        }
    }
}
