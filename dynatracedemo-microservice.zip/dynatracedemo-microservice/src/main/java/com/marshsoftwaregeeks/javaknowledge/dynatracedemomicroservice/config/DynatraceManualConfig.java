//package com.marshsoftwaregeeks.javaknowledge.dynatracedemomicroservice.config;
//
//import io.micrometer.dynatrace.DynatraceConfig;
//import io.micrometer.dynatrace.DynatraceMeterRegistry;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import java.time.Duration;
//
//@Configuration
//public class DynatraceManualConfig {
//
//    @Bean
//    public DynatraceConfig dynatraceConfig() {
//        return new DynatraceConfig() {
//            @Override
//            public String get(String key) {
//                return null;
//            }
//
//            @Override
//            public String apiToken() {
//                return "dt0c01.655BJP4WTSUVRXXI6SILSTJC.OD4LVHJKE3XOBG3SZ2N7LICVHBOFN7GTEJUORI67TKFVW2PQKVKUMUIXFLHNN76M";
//            }
//
//            @Override
//            public String uri() {
//                return "https://kbs54697.live.dynatrace.com/api/v2/metrics/ingest";
//            }
//
//            @Override
//            public String deviceId() {
//                return "localhost";
//            }
//
//            @Override
//            public String group() {
//                return "spring-boot-metrics";
//            }
//
//            @Override
//            public Duration step() {
//                return Duration.ofMinutes(1);
//            }
//        };
//    }
//
//    @Bean
//    public DynatraceMeterRegistry dynatraceMeterRegistry(DynatraceConfig config) {
//        return DynatraceMeterRegistry.builder(config).build();
//    }
//}