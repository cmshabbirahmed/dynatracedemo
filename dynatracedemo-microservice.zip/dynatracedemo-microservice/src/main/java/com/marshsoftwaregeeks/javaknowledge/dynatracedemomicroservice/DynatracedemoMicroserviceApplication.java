package com.marshsoftwaregeeks.javaknowledge.dynatracedemomicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;





@SpringBootApplication
public class DynatracedemoMicroserviceApplication {

//	@Autowired
//
//	DebugMicrometerConfig debugMicrometerConfig;

//	@PostConstruct
//	public void testConnection() {
//		try {
//			HttpURLConnection con = (HttpURLConnection)
//					new URL("https://kbs54697.live.dynatrace.com/api/v2/metrics/ingest").openConnection();
//			con.setRequestProperty("Authorization", "Api-Token dt0c01.655BJP4WTSUVRXXI6SILSTJC.OD4LVHJKE3XOBG3SZ2N7LICVHBOFN7GTEJUORI67TKFVW2PQKVKUMUIXFLHNN76M");
//			con.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
//			con.setDoOutput(true);
//			con.getOutputStream().write("test.metric count,delta=1".getBytes());
//			System.out.println("Startup test: Response code from Dynatrace = " + con.getResponseCode());
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	public static void main(String[] args) {
		SpringApplication.run(DynatracedemoMicroserviceApplication.class, args);
	}

}
